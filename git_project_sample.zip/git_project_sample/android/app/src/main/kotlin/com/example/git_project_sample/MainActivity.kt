package com.example.git_project_sample

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
